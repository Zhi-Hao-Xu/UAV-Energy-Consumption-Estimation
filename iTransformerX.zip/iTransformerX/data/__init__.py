from data.data_loader import split_data_cnn, data_detime
