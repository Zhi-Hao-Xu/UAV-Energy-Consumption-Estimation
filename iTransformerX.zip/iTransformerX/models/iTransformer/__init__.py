# from iTransformer.iTransformer2D import iTransformer2D
#
# from iTransformer.iTransformerFFT import iTransformerFFT
from models.iTransformer.iTransformer import iTransformer_block,iTransformer_single